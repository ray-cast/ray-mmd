Keyboards:

Global Setting:
    ESC : Switch Mode Between the EditMode / FirstPersonCamera

Camera Window:
    Ctrl +  Left   Mouse : Picker Model/Subset
            Middle Mouse : Moving Camera
            Right  Mouse : Rotation Camera
    Shift Pressed : Speed+

Assets & Materials Window:
            Left Click : Drag & Drop Texture or Material to Inspector Window
    Ctrl  + Left Mouse : Selectable Assets&Materials for Export Resources
    Shift + Left Mouse : Selectable Assets&Materials for Export Resources

Hierarchy :
    Selected Camera Item : FirstPerson Edit
    Selected Mesh Item   : Camera Following the Mesh